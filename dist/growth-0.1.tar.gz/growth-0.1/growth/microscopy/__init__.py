from .microscopy import SyntheticMicroscopy
